package com.br.dashmon.reports;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportsApplicationTests {

	@Test
	void contextLoads() {
	}

}
